import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
import joblib

# Set seed for reproducibility
np.random.seed(42)

# Generate random data
time_on_books = np.random.randint(1, 36, 1000)
total_paid_last_12_months = np.random.uniform(0, 10000, 1000)
total_debt_in_arrears = np.random.uniform(0, 5000, 1000)
pay_or_not_pay = np.random.randint(0, 2, 1000)

# Create DataFrame
data = pd.DataFrame({
    'time_on_books': time_on_books,
    'total_paid_last_12_months': total_paid_last_12_months,
    'total_debt_in_arrears': total_debt_in_arrears,
    'pay_or_not_pay': pay_or_not_pay
})

# Save to Excel
data.to_excel('fintech.xlsx', index=False)

# Split data into train and test sets
X = data[['time_on_books', 'total_paid_last_12_months', 'total_debt_in_arrears']]
y = data['pay_or_not_pay']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and train the logistic regression model
model = LogisticRegression()
model.fit(X_train, y_train)

# Make predictions on train and test data
y_train_pred = model.predict(X_train)
y_test_pred = model.predict(X_test)

# Print classification reports for train and test data
print('Train Data Classification Report:\n', classification_report(y_train, y_train_pred))
print('Test Data Classification Report:\n', classification_report(y_test, y_test_pred))

# Save the model to a file
joblib.dump(model, 'fintech.joblib')
